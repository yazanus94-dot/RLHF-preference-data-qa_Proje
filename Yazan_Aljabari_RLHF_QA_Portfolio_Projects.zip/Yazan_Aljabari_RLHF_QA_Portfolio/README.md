# QA for AI / RLHF: Two Portfolio Projects

Author: **Yazan Aljabari** | QA Automation Engineer | GitHub: https://github.com/yazanus94-dot

Two small, fully tested Python projects that show how I approach quality assurance for AI systems:

1. **`project1-llm-eval-qa-harness`**: evaluating model *responses* (rubrics, critical checks, flakiness, release gate).
2. **`project2-preference-data-qa`**: auditing RLHF *preference data* (bias, annotator agreement, consistency).

Both use only synthetic data, need Python 3.9+ and `pytest`, and run in CI.
They are personal portfolio projects, not client work.
